# Lista de Exercícios — 3º Trimestre

Repositório organizado com 30 exercícios.

## Estrutura
- `01_Kotlin` — ex01 a ex05
- `02_Java` — ex06 a ex09
- `03_C` — ex10 a ex13
- `04_CPP` — ex14 a ex17
- `05_CSharp` — ex18 a ex20
- `06_TypeScript` — ex21 a ex23
- `07_SQL` — ex24 a ex26
- `08_PHP` — ex27 a ex30
